-- Apex League: username-only admin login helper
-- Run this in Supabase SQL Editor after the existing Apex League schema.
-- It does NOT expose the password. It only maps an approved username to its Auth email.

ALTER TABLE public.admin_profiles
ADD COLUMN IF NOT EXISTS username text;

UPDATE public.admin_profiles
SET username = display_name
WHERE username IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS admin_profiles_username_lower_idx
ON public.admin_profiles (lower(username));

CREATE OR REPLACE FUNCTION public.get_admin_login_email(p_username text)
RETURNS text
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT au.email
  FROM public.admin_profiles ap
  JOIN auth.users au ON au.id = ap.user_id
  WHERE ap.approved = true
    AND lower(ap.username) = lower(trim(p_username))
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_admin_login_email(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_admin_login_email(text) TO anon, authenticated;

-- Make sure your admin username is exactly Its_Jake.
UPDATE public.admin_profiles
SET username = 'Its_Jake', display_name = 'Its_Jake', approved = true
WHERE lower(display_name) = lower('Its_Jake') OR lower(username) = lower('Its_Jake');
