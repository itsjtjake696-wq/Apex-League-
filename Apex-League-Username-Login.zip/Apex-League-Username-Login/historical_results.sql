-- APEX LEAGUE HISTORICAL RESULTS IMPORT
-- This consolidates the results that were entered/confirmed in the previous Apex League chat.
-- It intentionally leaves the two unfinished Day 10 fixtures out.
-- IMPORTANT: review the first two lines below before running if you already have these exact rows in Supabase.

-- Remove existing results only if you want this import to be the single source of truth.
-- DELETE FROM public.results;

WITH games(matchday, home, hs, ascore, away) AS (
  VALUES
  (1,'AresNova',0,2,'Theo123'),
  (1,'KD4',1,1,'MasheleFC'),
  (2,'MasheleFC',0,0,'AresNova'),
  (2,'Beyou',0,0,'_Cody'),
  (2,'KD4',0,0,'Toni_14'),
  (3,'Theo123',3,0,'_Cody'),
  (3,'MasheleFC',0,0,'Ronaldo'),
  (3,'KD4',2,2,'Tiyani12'),
  (3,'Beyou',3,0,'NtlakusoCR7'),
  (3,'AresNova',0,3,'Toni_14'),
  (4,'Theo123',1,0,'KD4'),
  (4,'NtlakusoCR7',0,0,'Toni_14'),
  (4,'AresNova',0,3,'Beyou'),
  (4,'Ronaldo',0,3,'_Cody'),
  (4,'Its_Jake',3,0,'Tiyani12'),
  (5,'_Cody',7,0,'Its_Jake'),
  (5,'MasheleFC',1,0,'Theo123'),
  (5,'Beyou',1,0,'KD4'),
  (5,'Tiyani12',3,0,'AresNova'),
  (5,'Ronaldo',0,3,'Toni_14'),
  (6,'AresNova',3,0,'Ronaldo'),
  (6,'Beyou',3,1,'Its_Jake'),
  (6,'_Cody',4,0,'KD4'),
  (6,'Theo123',3,0,'Ronaldo'),
  (6,'AresNova',3,0,'Tiyani12'),
  (6,'MasheleFC',3,0,'NtlakusoCR7'),
  (8,'Its_Jake',3,0,'Toni_14'),
  (8,'KD4',3,0,'Ronaldo'),
  (8,'NtlakusoCR7',0,3,'Tiyani12'),
  (8,'MasheleFC',2,0,'_Cody'),
  (8,'Beyou',2,2,'Theo123'),
  (9,'AresNova',3,0,'Its_Jake'),
  (9,'Beyou',2,1,'KD4'),
  (9,'Tiyani12',3,0,'Ronaldo'),
  (9,'NtlakusoCR7',0,3,'_Cody'),
  (9,'Theo123',3,0,'Toni_14'),
  (10,'KD4',1,0,'AresNova'),
  (10,'Its_Jake',3,0,'NtlakusoCR7'),
  (10,'Beyou',3,0,'Ronaldo')
), resolved AS (
  SELECT g.matchday,
         hp.id home_player,
         ap.id away_player,
         g.hs home_score,
         g.ascore away_score
  FROM games g
  JOIN public.players hp ON hp.name = g.home
  JOIN public.players ap ON ap.name = g.away
)
INSERT INTO public.results(matchday, home_player, away_player, home_score, away_score)
SELECT matchday, home_player, away_player, home_score, away_score
FROM resolved r
WHERE NOT EXISTS (
  SELECT 1 FROM public.results x
  WHERE x.matchday=r.matchday
    AND x.home_player=r.home_player
    AND x.away_player=r.away_player
    AND x.home_score=r.home_score
    AND x.away_score=r.away_score
);

-- Check the imported total:
SELECT COUNT(*) AS imported_or_existing_results FROM public.results;
